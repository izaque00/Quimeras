# quimera/utils/rate_limiter.py
"""
Rate Limiter usando algoritmo Token Bucket.

Controla a taxa de chamadas a APIs externas (LLMs, Redis, etc.)
para evitar rate limiting e falhas em cascata.

Uso:
    from quimera.utils.rate_limiter import TokenBucket
    
    llm_limiter = TokenBucket(rate=10, burst=15)  # 10 req/s, burst de 15
    
    async def chamar_llm(prompt):
        await llm_limiter.acquire()
        return await llm_client.generate(prompt)
"""

import asyncio
import logging
import time
import threading
from typing import Optional

logger = logging.getLogger(__name__)


class TokenBucket:
    """Implementação thread-safe de Token Bucket para rate limiting.

    Tokens são adicionados a uma taxa constante (rate) até um
    máximo (burst). Cada chamada consome 1 token. Se não houver
    tokens disponíveis, a chamada aguarda.

    Attributes:
        rate: Tokens adicionados por segundo.
        burst: Número máximo de tokens acumulados.
    """

    def __init__(self, rate: float, burst: int = 10):
        if rate <= 0:
            raise ValueError(f"Rate deve ser > 0, recebido {rate}")
        self.rate = rate
        self.burst = burst
        self._tokens = float(burst)
        self._last_refill = time.monotonic()
        self._lock = threading.Lock()
        self.total_acquired: int = 0
        self.total_waited: float = 0.0

    def _refill(self):
        """Adiciona tokens baseado no tempo decorrido."""
        now = time.monotonic()
        elapsed = now - self._last_refill
        self._tokens = min(float(self.burst), self._tokens + elapsed * self.rate)
        self._last_refill = now

    def acquire(self, blocking: bool = True, timeout: Optional[float] = None) -> bool:
        """Tenta adquirir um token (síncrono).

        Args:
            blocking: Se True, aguarda até ter token disponível.
            timeout: Tempo máximo de espera em segundos.

        Returns:
            True se adquiriu o token, False se timeout.
        """
        deadline = time.monotonic() + timeout if timeout else None
        while True:
            with self._lock:
                self._refill()
                if self._tokens >= 1.0:
                    self._tokens -= 1.0
                    self.total_acquired += 1
                    return True
            if not blocking:
                return False
            if deadline and time.monotonic() >= deadline:
                return False
            time.sleep(0.05)

    async def async_acquire(self, timeout: Optional[float] = None) -> bool:
        """Versão assíncrona de acquire."""
        deadline = time.monotonic() + timeout if timeout else None
        while True:
            with self._lock:
                self._refill()
                if self._tokens >= 1.0:
                    self._tokens -= 1.0
                    self.total_acquired += 1
                    return True
            if deadline and time.monotonic() >= deadline:
                logger.warning(
                    f"TokenBucket: timeout após {timeout}s "
                    f"(rate={self.rate}/s, tokens={self._tokens:.1f})"
                )
                return False
            await asyncio.sleep(0.05)

    def available(self) -> float:
        """Retorna número de tokens disponíveis no momento."""
        with self._lock:
            self._refill()
            return self._tokens


# Instâncias padrão para uso no sistema
llm_rate_limiter = TokenBucket(rate=5, burst=10)  # 5 chamadas LLM/s
compilation_rate_limiter = TokenBucket(rate=2, burst=3)  # 2 compilações/s
