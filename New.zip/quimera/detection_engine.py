"""
Quimera Detection Engine — Static analysis via regex + AST + heuristics.
"""
import re
from dataclasses import dataclass, field
from typing import List

@dataclass
class Issue:
    cwe_id: str
    line: int
    description: str
    confidence: float = 0.8

@dataclass
class DetectionReport:
    issues: List[Issue] = field(default_factory=list)

class DetectionEngine:
    def detect_in_file(self, code: str, path: str, lang: str) -> DetectionReport:
        report = DetectionReport()
        lines = code.split('\n')
        
        for i, line in enumerate(lines, 1):
            s = line.strip()
            # Skip non-code lines (includes, defines, comments, blanks)
            if not s or s.startswith('//') or s.startswith('/*') or s.startswith('*'):
                continue
            if s.startswith('#include') or s.startswith('#define') or s.startswith('#if'):
                continue
            if s.startswith('#endif') or s.startswith('#else') or s.startswith('#pragma'):
                continue
            
            # CWE-476: NULL dereference patterns
            if re.search(r'->|\.\w+', s) and not re.search(r'if\s*\(.*NULL|if\s*\(.*!', s):
                if any(kw in s for kw in ['malloc', 'alloc', 'kmalloc', 'krealloc', 'copy_from', 'copy_to']):
                    continue
                if '=' not in s:
                    report.issues.append(Issue('CWE-476', i, 
                        f'Dereference of parameter without NULL check', 0.5))
            
            # CWE-401: Memory leak
            if re.search(r'(malloc|kmalloc|kzalloc)\s*\(', s):
                func_end = self._find_func_end(lines, i)
                func_body = '\n'.join(lines[i:func_end+1])
                mallocs = len(re.findall(r'(?:malloc|kmalloc|kzalloc)\s*\(', func_body))
                frees = len(re.findall(r'(?:free|kfree)\s*\(', func_body))
                if mallocs > frees:
                    var_match = re.search(r'(\w+)\s*=\s*(?:malloc|kmalloc|kzalloc)', s)
                    varname = var_match.group(1) if var_match else 'memory'
                    report.issues.append(Issue('CWE-401', i,
                        f'Memory allocated but potentially leaked — {varname} not freed on all paths', 0.6))
            
            # CWE-416: free without NULL
            if re.search(r'(?:free|kfree)\s*\((\w+)', s):
                var = re.search(r'(?:free|kfree)\s*\((\w+)', s).group(1)
                next_lines = '\n'.join(lines[i:min(i+5, len(lines))])
                if f'{var} = NULL' not in next_lines:
                    report.issues.append(Issue('CWE-416', i,
                        f'free({var}) without {var} = NULL — risk indicator', 0.4))
            
            # CWE-120: buffer overflow risk
            if re.search(r'(strcpy|sprintf|gets|scanf)\s*\(', s) and 'n' not in s.split('(')[0]:
                report.issues.append(Issue('CWE-120', i,
                    'Unchecked buffer operations leading to memory corruption', 0.7))
            
            # CWE-134: format string
            if re.search(r'printf\s*\(\s*\w+\s*[),]', s):
                report.issues.append(Issue('CWE-134', i,
                    'printf/fprintf with variable format string — risk if input is external', 0.4))
        
        return report
    
    def _find_func_end(self, lines, start):
        brace = 0
        for i in range(start, len(lines)):
            brace += lines[i].count('{') - lines[i].count('}')
            if brace == 0 and i > start:
                return i
        return len(lines) - 1
