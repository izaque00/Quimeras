"""
ProjectContext v1 — ADAPTER de compatibilidade.

⚠️  ESTE MÓDULO É UM ADAPTER — NÃO CONTÉM LÓGICA DE NEGÓCIO.
    Toda lógica real está em project_context_v2.py (implementação oficial).

    Este arquivo existe APENAS para manter compatibilidade com código
    legado que importa de project_context.py. Ele delega todas as
    chamadas para ProjectContextV2.

    REGRA: Nenhum código novo deve importar deste módulo.
           Use diretamente: from quimera.cognition.project_context_v2 import ProjectContextV2

Autor: Quimera MarkX — OMinivers
"""
import logging
from typing import Any, Dict, List, Optional

from quimera.cognition.project_context_v2 import (
    ProjectContextV2,
    FactNode,
    BeliefNode,
    DecisionNode,
    ConfidenceLevel,
    ContextType,
)

logger = logging.getLogger("quimera.cognition.project_context")


# ═══════════════════════════════════════════════════════════════
# ADAPTER — Delegação para ProjectContextV2 (implementação oficial)
# ═══════════════════════════════════════════════════════════════

class ProjectContext:
    """Adapter de compatibilidade — delega para ProjectContextV2.
    
    Mantém a mesma interface do v1 para código legado,
    mas internamente usa o v2 (facts/beliefs/decisions + drift detection).
    """
    
    def __init__(self, project_name: str = "", project_path: str = ""):
        self._v2 = ProjectContextV2(project_name=project_name, project_path=project_path)
        
        # Compatibilidade: expor atributos comuns
        self.project_name = project_name
        self.project_path = project_path
        self.components: Dict[str, Any] = {}
        self.vulnerabilities: List[Any] = []
        self.dependencies: List[str] = []
    
    # ── Delegação ─────────────────────────────────────────────
    
    @property
    def facts(self):
        return self._v2.facts
    
    @property
    def beliefs(self):
        return self._v2.beliefs
    
    @property
    def decisions(self):
        return self._v2.decisions
    
    @property
    def version(self):
        return self._v2.meta.version
    
    def add_fact(self, key: str, value: Any, source: str = "adapter"):
        self._v2.add_fact(key, value, source)
    
    def add_belief(self, key: str, value: Any, confidence=None, source: str = "adapter"):
        conf = confidence if confidence else ConfidenceLevel.MEDIUM
        self._v2.add_belief(key, value, conf, source)
    
    def record_decision(self, action: str, rationale: str) -> str:
        return self._v2.record_decision(action, rationale)
    
    def check_drift(self) -> Dict[str, Any]:
        return self._v2.check_drift()
    
    def fork(self, context_type=None, branch_name: str = "fork"):
        ct = context_type if context_type else ContextType.GLOBAL
        new_v2 = self._v2.fork(ct, branch_name)
        adapter = ProjectContext.__new__(ProjectContext)
        adapter._v2 = new_v2
        adapter.project_name = new_v2.project_name
        adapter.project_path = new_v2.project_path
        adapter.components = {}
        adapter.vulnerabilities = []
        adapter.dependencies = []
        return adapter
    
    def merge_back(self, source: 'ProjectContext'):
        self._v2.merge_back(source._v2)
    
    def summary(self) -> str:
        return self._v2.summary()
    
    def to_dict(self) -> Dict[str, Any]:
        return self._v2.to_dict()
    
    def __repr__(self):
        return f"ProjectContext(v{self.version}, {len(self.facts)} facts, {len(self.beliefs)} beliefs)"


# ═══════════════════════════════════════════════════════════════
# Re-exportações para compatibilidade
# ═══════════════════════════════════════════════════════════════

# Classes reexportadas do v2 para não quebrar imports existentes
ComponentInfo = None  # Substituído por FactNode
DependencyGraph = None
VulnerabilityReport = None
RiskLevel = None


# Log de deprecação
logger.info("project_context.py: Modo adapter ativo. Use project_context_v2 diretamente.")
