#!/usr/bin/env python3
"""
AutoCoder AI - Sistema de Correção Automática com IA Generativa
Exemplo de implementação de IA que detecta, analisa e corrige código automaticamente
usando modelos de linguagem avançados.
"""

import ast
import asyncio
import json
import logging
import re
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Any, Optional, Tuple
import hashlib

# Simulação de cliente de IA (em produção seria OpenAI, Anthropic, etc.)
class AICodeClient:
    """Cliente simulado para IA generativa"""

    def __init__(self):
        self.model_name = "gpt-4-code-specialist"
        self.max_tokens = 4096

    async def generate_fix(self, problem_code: str, problem_description: str, context: str = "") -> str:
        """Gera correção automaticamente usando IA"""

        # Simulação de diferentes tipos de correções
        fixes = {
            "sql_injection": self._fix_sql_injection,
            "loop_optimization": self._fix_loop_optimization,
            "security_hardcoded": self._fix_hardcoded_secrets,
            "exception_handling": self._fix_exception_handling,
            "performance_string": self._fix_string_performance,
            "complexity_reduction": self._fix_complexity,
            "memory_optimization": self._fix_memory_usage,
            "async_optimization": self._fix_async_patterns
        }

        # Detecta tipo de problema
        problem_type = self._detect_problem_type(problem_code, problem_description)

        if problem_type in fixes:
            return await fixes[problem_type](problem_code, context)
        else:
            return await self._generic_ai_fix(problem_code, problem_description, context)

    def _detect_problem_type(self, code: str, description: str) -> str:
        """Detecta o tipo de problema para aplicar correção específica"""
        code_lower = code.lower()
        desc_lower = description.lower()

        if "sql" in desc_lower and "injection" in desc_lower:
            return "sql_injection"
        elif "loop" in desc_lower and ("nested" in desc_lower or "complexity" in desc_lower):
            return "loop_optimization"
        elif "hardcoded" in desc_lower or "credential" in desc_lower:
            return "security_hardcoded"
        elif "exception" in desc_lower or "error" in desc_lower:
            return "exception_handling"
        elif "string" in desc_lower and "concatenation" in desc_lower:
            return "performance_string"
        elif "complexity" in desc_lower:
            return "complexity_reduction"
        elif "memory" in desc_lower:
            return "memory_optimization"
        elif "async" in desc_lower:
            return "async_optimization"

        return "generic"

    async def _fix_sql_injection(self, code: str, context: str) -> str:
        """Corrige vulnerabilidades de SQL injection"""

        # Detecta padrões de SQL injection
        if 'f"SELECT' in code or "f'SELECT" in code:
            # Converte para parameterized query
            fixed_code = re.sub(
                r'f"SELECT \* FROM (\w+) WHERE (\w+) = \'{\w+}\'\"',
                r'cursor.execute("SELECT * FROM \1 WHERE \2 = ?", (\3,))',
                code
            )

            if fixed_code != code:
                return f"""# 🔒 AI Auto-Fix: SQL Injection → Prepared Statement
{fixed_code}

# ✅ Correção aplicada:
# - Substituído f-string por prepared statement
# - Adicionado parâmetro seguro
# - Prevenção de SQL injection"""

        # Fallback para correção genérica
        return f"""# 🔒 AI Auto-Fix: SQL Injection Prevention
import sqlite3

def safe_query(conn, table, column, value):
    cursor = conn.cursor()
    query = f"SELECT * FROM {{table}} WHERE {{column}} = ?"
    cursor.execute(query, (value,))
    return cursor.fetchall()

# ✅ Use prepared statements sempre
# ✅ Valide inputs
# ✅ Use ORM quando possível"""

    async def _fix_loop_optimization(self, code: str, context: str) -> str:
        """Otimiza loops aninhados"""

        return f"""# ⚡ AI Auto-Fix: Loop Optimization
# Original tinha complexidade O(n³)
# Otimizado para O(n²) usando sets e algoritmos eficientes

def optimized_algorithm(data):
    # Usando set para lookup O(1)
    data_set = set(data)
    result = []

    for i, val_i in enumerate(data):
        for j, val_j in enumerate(data[i+1:], i+1):
            target = -(val_i + val_j)
            if target in data_set:
                result.append((i, j, data.index(target)))

    return result

# ✅ Reduzido de O(n³) para O(n²)
# ✅ Uso eficiente de estruturas de dados
# ✅ Eliminação de loops desnecessários"""

    async def _fix_hardcoded_secrets(self, code: str, context: str) -> str:
        """Corrige credenciais hardcoded"""

        return f"""# 🔐 AI Auto-Fix: Secure Credential Management
import os
from cryptography.fernet import Fernet

# ❌ NUNCA faça isso:
# PASSWORD = "admin123"
# API_KEY = "sk-1234567890abcdef"

# ✅ Faça isso:
PASSWORD = os.getenv('APP_PASSWORD')
API_KEY = os.getenv('API_KEY')

# Para desenvolvimento, use .env:
from dotenv import load_dotenv
load_dotenv()

# Para produção, use:
# - Azure Key Vault
# - AWS Secrets Manager
# - HashiCorp Vault
# - Kubernetes Secrets

class SecureConfig:
    def __init__(self):
        self.password = self._get_secure_value('APP_PASSWORD')
        self.api_key = self._get_secure_value('API_KEY')

    def _get_secure_value(self, key: str) -> str:
        value = os.getenv(key)
        if not value:
            raise ValueError(f"Required environment variable {{key}} not set")
        return value

# ✅ Credenciais em variáveis de ambiente
# ✅ Validação de configuração
# ✅ Preparado para produção"""

    async def _fix_exception_handling(self, code: str, context: str) -> str:
        """Melhora tratamento de exceções"""

        return f"""# 🛡️ AI Auto-Fix: Robust Exception Handling
import logging

def safe_division(a: float, b: float) -> float:
    \"\"\"Divisão segura com tratamento completo de erros\"\"\"
    try:
        if not isinstance(a, (int, float)) or not isinstance(b, (int, float)):
            raise TypeError("Arguments must be numbers")

        if b == 0:
            raise ZeroDivisionError("Division by zero is not allowed")

        result = a / b

        # Verifica overflow/underflow
        if abs(result) > 1e308:
            raise OverflowError("Result too large")

        return result

    except ZeroDivisionError as e:
        logging.error(f"Division error: {{e}}")
        return float('inf') if a > 0 else float('-inf')

    except TypeError as e:
        logging.error(f"Type error: {{e}}")
        raise

    except OverflowError as e:
        logging.error(f"Overflow error: {{e}}")
        return float('inf')

    except Exception as e:
        logging.error(f"Unexpected error: {{e}}")
        raise

# ✅ Tratamento específico por tipo de erro
# ✅ Logging adequado
# ✅ Type hints
# ✅ Documentação"""

    async def _fix_string_performance(self, code: str, context: str) -> str:
        """Otimiza concatenação de strings"""

        return f"""# ⚡ AI Auto-Fix: String Performance Optimization

# ❌ Lento: O(n²) complexity
# result = ""
# for item in items:
#     result += str(item) + ", "

# ✅ Rápido: O(n) complexity
def efficient_string_join(items):
    return ", ".join(str(item) for item in items)

# ✅ Para casos complexos:
from io import StringIO

def complex_string_building(data):
    buffer = StringIO()

    for item in data:
        if item.is_valid():
            buffer.write(f"{{item.name}}: {{item.value}}\\n")

    return buffer.getvalue()

# ✅ Para templates:
from string import Template

template = Template("Name: $name, Value: $value")
result = template.substitute(name="test", value=42)

# ✅ Para formatação moderna:
name, value = "test", 42
result = f"Name: {{name}}, Value: {{value}}"

# Performance comparison:
# String concatenation: O(n²) - SLOW
# join(): O(n) - FAST
# StringIO: O(n) - FAST for complex cases
# f-strings: O(n) - FAST and readable"""

    async def _fix_complexity(self, code: str, context: str) -> str:
        """Reduz complexidade ciclomática"""

        return f"""# 🧠 AI Auto-Fix: Complexity Reduction

# Quebra função complexa em funções menores e focadas

def validate_user_input(data: dict) -> tuple[bool, str]:
    \"\"\"Valida entrada do usuário\"\"\"
    if not data:
        return False, "Data is required"

    email_valid, email_msg = validate_email(data.get('email'))
    if not email_valid:
        return False, email_msg

    password_valid, password_msg = validate_password(data.get('password'))
    if not password_valid:
        return False, password_msg

    return True, "Valid"

def validate_email(email: str) -> tuple[bool, str]:
    \"\"\"Valida formato de email\"\"\"
    if not email:
        return False, "Email is required"

    if '@' not in email or '.' not in email:
        return False, "Invalid email format"

    return True, "Email valid"

def validate_password(password: str) -> tuple[bool, str]:
    \"\"\"Valida força da senha\"\"\"
    if not password:
        return False, "Password is required"

    if len(password) < 8:
        return False, "Password too short"

    if not any(c.isupper() for c in password):
        return False, "Password needs uppercase"

    return True, "Password valid"

# ✅ Cada função tem uma responsabilidade
# ✅ Fácil de testar individualmente
# ✅ Fácil de manter
# ✅ Complexidade reduzida"""

    async def _fix_memory_usage(self, code: str, context: str) -> str:
        """Otimiza uso de memória"""

        return f"""# 💾 AI Auto-Fix: Memory Optimization

import weakref
from functools import lru_cache
import gc

# ❌ Memory leak:
# global_cache = []
# def leak_function():
#     global global_cache
#     while True:
#         global_cache.append([0] * 1000000)

# ✅ Memory efficient:
class MemoryEfficientCache:
    def __init__(self, max_size: int = 1000):
        self._cache = {{}}
        self._max_size = max_size
        self._access_order = []

    def get(self, key):
        if key in self._cache:
            # Move to end (most recently used)
            self._access_order.remove(key)
            self._access_order.append(key)
            return self._cache[key]
        return None

    def set(self, key, value):
        if len(self._cache) >= self._max_size:
            # Remove least recently used
            lru_key = self._access_order.pop(0)
            del self._cache[lru_key]

        self._cache[key] = value
        self._access_order.append(key)

# ✅ Generator para grandes datasets:
def process_large_file(filename):
    with open(filename, 'r') as f:
        for line in f:
            yield line.strip()  # Process one line at a time

# ✅ Context managers para recursos:
class DatabaseConnection:
    def __enter__(self):
        self.conn = create_connection()
        return self.conn

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.conn.close()

# ✅ Weak references para evitar cycles:
class Node:
    def __init__(self, value):
        self.value = value
        self._children = []
        self._parent = None

    def add_child(self, child):
        child._parent = weakref.ref(self)
        self._children.append(child)

# ✅ Limpeza manual quando necessário:
def cleanup_resources():
    # Força garbage collection
    gc.collect()

# Performance tips:
# - Use generators ao invés de listas grandes
# - Implemente __slots__ em classes
# - Use weak references para evitar cycles
# - Context managers para recursos
# - Cache com limite de tamanho"""

    async def _fix_async_patterns(self, code: str, context: str) -> str:
        """Otimiza padrões assíncronos"""

        return f"""# ⚡ AI Auto-Fix: Async/Await Optimization

import asyncio
import aiohttp
from concurrent.futures import ThreadPoolExecutor
import time

# ✅ Async batch processing:
async def process_urls_efficiently(urls: list[str]) -> list[str]:
    \"\"\"Processa URLs em paralelo de forma eficiente\"\"\"

    async with aiohttp.ClientSession() as session:
        # Limit concurrent requests
        semaphore = asyncio.Semaphore(10)

        async def fetch_one(url):
            async with semaphore:
                try:
                    async with session.get(url, timeout=5) as response:
                        return await response.text()
                except Exception as e:
                    return f"Error: {{e}}"

        # Process all URLs concurrently
        tasks = [fetch_one(url) for url in urls]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        return results

# ✅ CPU-bound work with async:
async def cpu_intensive_with_async(data: list) -> list:
    \"\"\"Combina async com ThreadPoolExecutor para CPU-bound work\"\"\"

    def cpu_work(chunk):
        # Simulate CPU-intensive work
        return sum(x * x for x in chunk)

    # Split work into chunks
    chunk_size = len(data) // 4
    chunks = [data[i:i + chunk_size] for i in range(0, len(data), chunk_size)]

    # Use thread pool for CPU work
    with ThreadPoolExecutor(max_workers=4) as executor:
        loop = asyncio.get_event_loop()
        tasks = [
            loop.run_in_executor(executor, cpu_work, chunk)
            for chunk in chunks
        ]
        results = await asyncio.gather(*tasks)

    return results

# ✅ Async context manager:
class AsyncDatabaseConnection:
    async def __aenter__(self):
        self.conn = await create_async_connection()
        return self.conn

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.conn.close()

# ✅ Async generator:
async def async_file_reader(filename: str):
    \"\"\"Lê arquivo grande de forma assíncrona\"\"\"
    import aiofiles

    async with aiofiles.open(filename, 'r') as f:
        async for line in f:
            yield line.strip()

# ✅ Rate limiting:
class AsyncRateLimiter:
    def __init__(self, rate: int, period: float = 1.0):
        self.rate = rate
        self.period = period
        self.allowance = rate
        self.last_check = time.time()

    async def acquire(self):
        current = time.time()
        time_passed = current - self.last_check
        self.last_check = current

        self.allowance += time_passed * (self.rate / self.period)
        if self.allowance > self.rate:
            self.allowance = self.rate

        if self.allowance < 1.0:
            sleep_time = (1.0 - self.allowance) / self.rate
            await asyncio.sleep(sleep_time)
            self.allowance = 0.0
        else:
            self.allowance -= 1.0

# Best practices:
# - Use asyncio.gather() for concurrent operations
# - Limit concurrency with Semaphore
# - Use ThreadPoolExecutor for CPU-bound work
# - Implement proper error handling
# - Use async context managers
# - Rate limit external API calls"""

    async def _generic_ai_fix(self, code: str, description: str, context: str) -> str:
        """Correção genérica usando IA"""

        return f"""# 🤖 AI Auto-Fix: Generic Code Improvement

# Original code had issues:
# {description}

# AI-suggested improvements:

{code}

# ✅ Improvements applied:
# - Better error handling
# - Type hints added
# - Documentation improved
# - Performance optimized
# - Security enhanced
# - Code structure improved

# 💡 AI Recommendations:
# 1. Add comprehensive tests
# 2. Use static type checking (mypy)
# 3. Add logging for debugging
# 4. Consider using design patterns
# 5. Implement proper configuration management"""

@dataclass
class AutoCodeFix:
    """Representa uma correção automática de código"""
    original_code: str
    fixed_code: str
    problem_type: str
    confidence: float
    explanation: str
    estimated_impact: str
    backup_created: bool = False

class AutoCoderAI:
    """Sistema principal de correção automática com IA"""

    def __init__(self):
        self.ai_client = AICodeClient()
        self.fixes_applied = []
        self.logger = logging.getLogger("AutoCoderAI")

    async def analyze_and_fix(self, file_path: str, problems: List[Dict]) -> List[AutoCodeFix]:
        """Analisa problemas e gera correções automáticas"""

        self.logger.info(f"🤖 AutoCoder AI analisando {file_path}...")

        # Lê código original
        with open(file_path, 'r') as f:
            original_content = f.read()

        fixes = []

        for problem in problems:
            try:
                # Extrai contexto do problema
                line_num = problem.get('linha', 0)
                problem_type = problem.get('tipo', 'unknown')
                code_snippet = problem.get('codigo', '')
                description = problem.get('descricao', problem_type)

                # Gera correção com IA
                self.logger.info(f"   🔧 Corrigindo: {problem_type}")

                fixed_code = await self.ai_client.generate_fix(
                    code_snippet,
                    description,
                    original_content
                )

                # Calcula confiança baseada no tipo de problema
                confidence = self._calculate_confidence(problem_type, code_snippet)

                # Estima impacto
                impact = self._estimate_impact(problem_type)

                # Cria fix
                fix = AutoCodeFix(
                    original_code=code_snippet,
                    fixed_code=fixed_code,
                    problem_type=problem_type,
                    confidence=confidence,
                    explanation=f"AI Auto-Fix applied for {problem_type}",
                    estimated_impact=impact
                )

                fixes.append(fix)

            except Exception as e:
                self.logger.error(f"❌ Erro ao gerar correção: {e}")

        self.fixes_applied.extend(fixes)
        return fixes

    def _calculate_confidence(self, problem_type: str, code: str) -> float:
        """Calcula confiança na correção"""

        confidence_map = {
            'sql_injection': 0.95,
            'security_hardcoded': 0.90,
            'loop_optimization': 0.85,
            'string_performance': 0.90,
            'exception_handling': 0.88,
            'complexity_reduction': 0.75,
            'memory_optimization': 0.80,
            'async_optimization': 0.85
        }

        base_confidence = confidence_map.get(problem_type, 0.70)

        # Ajusta baseado na complexidade do código
        if len(code) > 200:
            base_confidence -= 0.1
        if len(code.split('\n')) > 10:
            base_confidence -= 0.05

        return max(0.5, min(0.99, base_confidence))

    def _estimate_impact(self, problem_type: str) -> str:
        """Estima impacto da correção"""

        impact_map = {
            'sql_injection': 'Critical - Security vulnerability fixed',
            'security_hardcoded': 'High - Credentials secured',
            'loop_optimization': 'High - Performance improved significantly',
            'string_performance': 'Medium - Performance improved',
            'exception_handling': 'Medium - Stability improved',
            'complexity_reduction': 'Medium - Maintainability improved',
            'memory_optimization': 'High - Memory usage optimized',
            'async_optimization': 'High - Concurrency improved'
        }

        return impact_map.get(problem_type, 'Low - Code quality improved')

    async def apply_fixes_to_file(self, file_path: str, fixes: List[AutoCodeFix],
                                 create_backup: bool = True) -> Dict[str, Any]:
        """Aplica correções ao arquivo"""

        if create_backup:
            backup_path = f"{file_path}.backup.{int(time.time())}"
            with open(file_path, 'r') as original, open(backup_path, 'w') as backup:
                backup.write(original.read())
            self.logger.info(f"💾 Backup criado: {backup_path}")

        # Por agora, só mostra as correções (em produção aplicaria no código)
        result = {
            'file_path': file_path,
            'fixes_applied': len(fixes),
            'total_confidence': sum(fix.confidence for fix in fixes) / len(fixes) if fixes else 0,
            'backup_created': create_backup,
            'summary': self._generate_fix_summary(fixes)
        }

        return result

    def _generate_fix_summary(self, fixes: List[AutoCodeFix]) -> Dict[str, Any]:
        """Gera resumo das correções"""

        by_type = {}
        total_confidence = 0

        for fix in fixes:
            if fix.problem_type not in by_type:
                by_type[fix.problem_type] = 0
            by_type[fix.problem_type] += 1
            total_confidence += fix.confidence

        return {
            'fixes_by_type': by_type,
            'average_confidence': total_confidence / len(fixes) if fixes else 0,
            'high_confidence_fixes': len([f for f in fixes if f.confidence > 0.8]),
            'critical_fixes': len([f for f in fixes if 'Critical' in f.estimated_impact])
        }

# Demonstração da funcionalidade
async def demo_autocoder_ai():
    """Demonstra o AutoCoder AI em ação"""

    print("""
╔══════════════════════════════════════════════════════════════════════════════╗
║                                                                              ║
║                    🤖 AUTOCODER AI - DEMONSTRAÇÃO 🤖                        ║
║                                                                              ║
║           Correção Automática de Código com IA Generativa                   ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝
    """)

    # Cria instância do AutoCoder
    autocoder = AutoCoderAI()

    # Problemas simulados (vindos do sistema Quimera)
    problems = [
        {
            'linha': 5,
            'tipo': 'sql_injection',
            'codigo': 'query = f"SELECT * FROM users WHERE name = \'{username}\'"',
            'descricao': 'SQL Injection vulnerability detected'
        },
        {
            'linha': 15,
            'tipo': 'security_hardcoded',
            'codigo': 'API_KEY = "sk-1234567890abcdef"',
            'descricao': 'Hardcoded API key found'
        },
        {
            'linha': 25,
            'tipo': 'loop_optimization',
            'codigo': 'for i in range(len(data)):\n    for j in range(len(data)):\n        for k in range(len(data)):',
            'descricao': 'Nested loops with O(n³) complexity'
        }
    ]

    print("🔍 Problemas detectados pelo Quimera:")
    for i, problem in enumerate(problems, 1):
        print(f"   {i}. {problem['tipo']} (linha {problem['linha']})")

    print("\n🤖 AutoCoder AI gerando correções...")

    # Gera correções
    fixes = await autocoder.analyze_and_fix("exemplo.py", problems)

    print(f"\n✅ {len(fixes)} correções geradas:")

    for i, fix in enumerate(fixes, 1):
        print(f"\n{i}. {fix.problem_type}")
        print(f"   Confiança: {fix.confidence:.0%}")
        print(f"   Impacto: {fix.estimated_impact}")
        print(f"   Código original: {fix.original_code[:50]}...")
        print(f"   ✨ Correção aplicada com IA generativa!")

    # Mostra uma correção completa
    if fixes:
        print(f"\n🔍 EXEMPLO DE CORREÇÃO COMPLETA:")
        print("=" * 80)
        print(fixes[0].fixed_code)

    print(f"\n🎯 RESUMO:")
    print(f"   🤖 AutoCoder AI processou {len(problems)} problemas")
    print(f"   ✅ Gerou {len(fixes)} correções inteligentes")
    print(f"   📈 Confiança média: {sum(f.confidence for f in fixes) / len(fixes):.0%}")
    print(f"   🚀 Pronto para aplicar automaticamente!")

if __name__ == "__main__":
    asyncio.run(demo_autocoder_ai())