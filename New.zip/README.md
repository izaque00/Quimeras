# Quimera — Automated Code Audit & Patching Pipeline

Quimera is a multi-layer automated code analysis and repair platform for C/C++.

## Architecture

```
Detection Engine (17 rules)
    -> Evidence Builder (safe/risky/uncertain/context-dependent)
    -> Correlation Engine (findings -> root causes)
    -> Resolution States ([OK]/[FIX]/[INV]/[UNK])
    -> Deep Investigation (UNKNOWN -> dossier)
    -> Patch Synthesis (2-3 fix candidates)
    -> Build Integration (project build + tests + benchmark)
    -> Validator Plugins (compile/build/tests/benchmark/ASan/UBSan/fuzzing)
    -> Patch Memory (remembers per project/compiler/arch)

Confidence Score: compile(10) + build(20) + tests(25) + benchmark(10) + ASan(15) + UBSan(10) + fuzzing(10) = MAX 100
```

## Validation Levels

| Level | Validator | Weight | Detects |
|---|---|---|---|
| N1 | Syntax | - | Well-formed code |
| N2 | Compile | 10 | gcc -Wall -Werror |
| N3 | Build | 20 | Full project build |
| N4 | Tests | 25 | Project test suite |
| N5 | Benchmark | 10 | Before/after regressions (>10%) |
| N6 | ASan | 15 | Use-after-free, buffer overflow, leaks |
| N7 | UBSan | 10 | Int overflow, null deref, misalignment |
| N8 | Fuzzing | 10 | Crash discovery (AFL++/libFuzzer) |

## Modules

| Module | Purpose |
|---|---|
| quimera/detection_engine.py | 17 detection rules (CWE-416/476/120/190/134/667) |
| quimera/evidence_score.py | Multi-dim confidence + failure tracking |
| quimera/correlation_engine.py | Groups findings into root causes |
| quimera/resolution_states.py | [OK] RESOLVED, [FIX] CANDIDATE, [INV] INVESTIGATE, [UNK] UNKNOWN |
| quimera/deep_investigation.py | UNKNOWN triggers investigation, produces dossier |
| quimera/knowledge_acquisition.py | Pipeline: catalog -> web -> LLM -> sandbox -> learn |
| quimera/real_knowledge_acquisition.py | 12 real bug patterns with solutions |
| quimera/fix_profile.py | Multi-dimensional confidence per fix |
| quimera/patch_synthesis.py | Generates 2-3 fix candidates per finding |
| quimera/patch_memory.py | Fix catalog with per-project/compiler/arch evidence |
| quimera/build_integration.py | Validates against real project build systems |
| quimera/pipeline.py | H1->H6 pipeline orchestration |
| quimera/validators/ | Plugin system (7 validators, extensible) |

## Key Design

1. **"I don't know" is a formal state** — UNKNOWN triggers Deep Investigation, not guessing
2. **Evidence-based** — every finding has safe/risky/uncertain/context-dependent classification
3. **No fix without validation** — patches must pass real project build + tests + benchmark
4. **Context-aware** — Patch Memory tracks per-project/compiler/arch: `is_safe_for("linux-kernel-mm")`
5. **Failure tracking** — records where fixes FAILED, not just successes
6. **Plugin architecture** — add validators without changing core
7. **Confidence scoring** — patches rated 0-100 based on cumulative evidence

## Benchmarks

- **libjpeg-turbo**: 271 C files, 622 findings, 461 files/s, 5 CWE groups classified
- **Linux kernel (mm/ + fs/ext4)**: 204 C files, 1636 findings, 68 files/s
- **Unknown bugs**: 4/6 novel patterns fixed with synthesis, 2 admitted as UNKNOWN

## Requirements

- Python 3.10+
- gcc or clang (for patch validation)
- Project build system (make/cmake/cargo/etc.) for full validation
